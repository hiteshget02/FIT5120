CREATE DATABASE  IF NOT EXISTS "iteration2db" /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `iteration2db`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: db-mysql-nyc1-01323-do-user-7348968-0.a.db.ondigitalocean.com    Database: iteration2db
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '20559e9d-9cca-11ea-8ec7-5a4d74d621e9:1-83';

--
-- Table structure for table `Aged_care_service_information`
--

DROP TABLE IF EXISTS `Aged_care_service_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Aged_care_service_information` (
  `Aged_care_service_name` varchar(45) NOT NULL,
  `address` varchar(45) DEFAULT NULL,
  `suburb` varchar(45) DEFAULT NULL,
  `Region` varchar(45) DEFAULT NULL,
  `Care_Type` varchar(45) DEFAULT NULL,
  `Service_Provide` varchar(45) DEFAULT NULL,
  `Organisation_type` varchar(45) DEFAULT NULL,
  `Remoteness` varchar(45) DEFAULT NULL,
  `postcode_state_postcode_state` int NOT NULL,
  KEY `fk_Aged_care_service_information_postcode_state1_idx` (`postcode_state_postcode_state`),
  CONSTRAINT `fk_Aged_care_service_information_postcode_state1` FOREIGN KEY (`postcode_state_postcode_state`) REFERENCES `postcode_state` (`postcode_state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Aged_care_service_information`
--

LOCK TABLES `Aged_care_service_information` WRITE;
/*!40000 ALTER TABLE `Aged_care_service_information` DISABLE KEYS */;
/*!40000 ALTER TABLE `Aged_care_service_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Hospital_information`
--

DROP TABLE IF EXISTS `Hospital_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Hospital_information` (
  `address` varchar(45) NOT NULL,
  `Remoteness` varchar(45) DEFAULT NULL,
  `suburb` varchar(45) DEFAULT NULL,
  `Funding_designmation` varchar(45) DEFAULT NULL,
  `postcode_state_postcode_state` int NOT NULL,
  KEY `fk_Hospital_information_postcode_state_idx` (`postcode_state_postcode_state`),
  CONSTRAINT `fk_Hospital_information_postcode_state` FOREIGN KEY (`postcode_state_postcode_state`) REFERENCES `postcode_state` (`postcode_state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Hospital_information`
--

LOCK TABLES `Hospital_information` WRITE;
/*!40000 ALTER TABLE `Hospital_information` DISABLE KEYS */;
/*!40000 ALTER TABLE `Hospital_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postcode_state`
--

DROP TABLE IF EXISTS `postcode_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `postcode_state` (
  `postcode_state` int NOT NULL,
  `state` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`postcode_state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postcode_state`
--

LOCK TABLES `postcode_state` WRITE;
/*!40000 ALTER TABLE `postcode_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `postcode_state` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-24  3:40:02
